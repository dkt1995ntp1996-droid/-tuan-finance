# TUAN FINANCE PWA
Bản web app chạy trên Safari iPhone. Có thu/chi KRW/VND, tỷ giá thủ công, ngân sách, tiết kiệm, cổ phiếu (giá trị nhập thủ công), vay/nợ, tài sản, báo cáo, xuất/nhập JSON và cache offline.

## Cài đặt
1. Đưa toàn bộ file trong thư mục này lên hosting static có HTTPS (GitHub Pages hoặc Cloudflare Pages).
2. Mở URL bằng Safari iPhone.
3. Chia sẻ → Thêm vào Màn hình chính → bật Mở dưới dạng ứng dụng web → Thêm.

Lưu ý: Đây là PWA, không phải IPA native. Dữ liệu lưu localStorage trên thiết bị; hãy sao lưu JSON định kỳ. Cảnh báo ngân sách hoạt động khi ghi giao dịch, không phải push notification nền. Giá cổ phiếu nhập thủ công. Không nhập mật khẩu ngân hàng hoặc dữ liệu nhạy cảm vào bản thử nghiệm này.
